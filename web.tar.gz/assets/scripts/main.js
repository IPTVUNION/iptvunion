
(function ($) {
  loginFunction = function()
{
                       
   $("#login_btn").click(function(){ 
        var check = true; 
        if($("#username").val().trim() == ''){
                $("#div_username").attr("data-validate", "Please enter username");
                $("#div_username").addClass('alert-validate');
                check = false;
        }else{ 
                $("#div_username").attr("data-validate", "");
                $("#div_username").removeClass('alert-validate');
        }
            
        if($("#password").val().trim() == ''){
                $("#div_password").attr("data-validate", "Please enter password");
                $("#div_password").addClass('alert-validate');
                check = false;
         }else{ 
                $("#div_password").attr("");
                $("#div_password").removeClass('alert-validate');
        }
         
    if(check){ 
           $.ajax({ 
            url:  'controllers/login.php',
            data: 'action=login&username='+$("#username").val()+'&password='+$("#password").val() ,  
            success: function(data) { 
                   var json  = $.parseJSON(data.toString()); 
                   if(json.hasOwnProperty('error_login')){ 
                        $("#error").html(json.error_login)
                        $("#error").css("display", "block");
                   }else{
                         location.href = 'index';
                   }  
                 }
              });     
    } 
  });
}


})(jQuery);