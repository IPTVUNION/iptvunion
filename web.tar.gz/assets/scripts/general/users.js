
(function ($) {
  add = function()
{
 
 
 



 var type_run="pc";
 
 
 if ($(window).width() < 700){ 
    $('#multiselect_mobile_div').show()
    $('#multiselect_pc_div').hide() 
    $('#from_mobile_div').show()
    $('#multiselect_to_div').hide();  
    
     
        $("#multiselect_rightAll").click(function() {  
           $("#from_mobile").append($("#multiselect_mobile").html().toString())
           $("#multiselect_mobile").html("");  
           $("#from_mobile > li").each(function () { $(this).removeClass("list-group-sel"); }); 
        }); 
     
         
         $("#multiselect_rightSelected").click(function() {  
         $("#multiselect_mobile > li").each(function () {
           if ($(this).hasClass("list-group-sel")) { 
                 $("#from_mobile").append($(this).removeClass("list-group-sel").clone())
                 $(this).remove();
           }
          });  
         }); 
          
          
         
         $("#multiselect_leftSelected").click(function() {  
         $("#from_mobile > li").each(function () {
           if ($(this).hasClass("list-group-sel")) { 
                 $("#multiselect_mobile").append($(this).removeClass("list-group-sel").clone())
                 $(this).remove();
           }
          });  
         });     
         
          
         $("#multiselect_leftAll").click(function() {  
           $("#multiselect_mobile").append($("#from_mobile").html().toString())
           $("#from_mobile").html(""); 
           $("#multiselect_mobile > li").each(function () { $(this).removeClass("list-group-sel"); });
         });  
    
    
 $("#multiselect_move_up").click(function() {     
 if($('#from_mobile li').length > $('#from_mobile li.list-group-sel').length & $('#from_mobile li.list-group-sel').length !=0) 
        var li_back =   $('#from_mobile li.list-group-sel').first().prev();    
          var  sel_li_list="";
         $("#from_mobile > li").each(function () { 
               if ($(this).hasClass("list-group-sel")) {
                  sel_li_list+=$(this)[0].outerHTML;
                  $(this).remove();
                }
          });    
        if (li_back.length){
             $(sel_li_list).insertBefore(li_back);
        }else{
           $('#from_mobile').html(sel_li_list + $('#from_mobile').html()); 
        }   
 });

 $("#multiselect_move_down").click(function() {    
     if($('#from_mobile li').length > $('#from_mobile li.list-group-sel').length & $('#from_mobile li.list-group-sel').length !=0) 
        var li_after =   $('#from_mobile li.list-group-sel').last().next().after();   
          var  sel_li_list="";
         $("#from_mobile > li").each(function () { 
               if ($(this).hasClass("list-group-sel")) {
                  sel_li_list+=$(this)[0].outerHTML;
                  $(this).remove();
                }
          });   
           
        if (li_after.length){
             $(sel_li_list).insertAfter(li_after);
        }else{
            $('#from_mobile').append(sel_li_list);
        } 
           
 });


 $("#multiselect_az").click(function() {    
          $("#from_mobile li").sort(asc_sort).appendTo('#from_mobile'); 
 });


 $("#multiselect_za").click(function() {     
        $("#from_mobile li").sort(dec_sort).appendTo('#from_mobile'); 
 });


 function asc_sort(a, b){
    return ($(b).text()) < ($(a).text()) ? 1 : -1;    
}

 
function dec_sort(a, b){
    return ($(b).text()) > ($(a).text()) ? 1 : -1;    

}
 
 
        
 $('#multiselect_mobile li').live('click', function() {
    if($(this).hasClass('list-group-sel')){
           $(this).removeClass('list-group-sel');
     }else{ 
            $(this).addClass('list-group-sel');
     }
 }); 
    
    
    
 $('#from_mobile li').live('click', function() {
    if($(this).hasClass('list-group-sel')){
           $(this).removeClass('list-group-sel');
     }else{ 
            $(this).addClass('list-group-sel');
     }
 }); 
    
    
      
    
 
  $('#submit1').click(function(e) {   
   var all_list="";
   $('#from_mobile li').each(function () {
   var list = $(this)[0].outerHTML 
   all_list+=list; 
   }); 
   all_list=all_list.replace(/<li/gi,"<option")
   all_list=all_list.replace(/<\/li/gi,"</option");    
   $('#multiselect_to').html(all_list);   
   $('#multiselect_to option').attr('selected', true); 
  });
    
     
     
 $('#from_ser').keyup(function(){ 
    var that = this, $allListElements = $('#multiselect_mobile > li');

    var $matchingListElements = $allListElements.filter(function(i, li){
        var listItemText = $(li).text().toUpperCase(), searchText = that.value.toUpperCase();
        return ~listItemText.indexOf(searchText);
    });
    
    $allListElements.hide();
    $matchingListElements.show(); 
 });

     
     
 $('#in_ser').keyup(function(){ 
    var that = this, $allListElements = $('#from_mobile > li');

    var $matchingListElements = $allListElements.filter(function(i, li){
        var listItemText = $(li).text().toUpperCase(), searchText = that.value.toUpperCase();
        return ~listItemText.indexOf(searchText);
    });
    
    $allListElements.hide();
    $matchingListElements.show(); 
 }); 
     
     
     
     
     
     
     
     
     
         
 }else{ 
    $('#multiselect_mobile_div').hide()
    $('#multiselect_pc_div').show()  
    $('#from_mobile_div').hide()
    $('#multiselect_to_div').show();  
    }










 
      $("#can").click(function() {
        window.location.href = "users"; 
      }); 
 
  
     $('#multiselect').multiselect({
        search: {
            left: '<input type="text" name="q" class="form-control" placeholder="Search..." />',
            right: '<input type="text" name="q" class="form-control" placeholder="Search..." />',
        },
        fireSearch: function(value) {
            return value.length > 3;
        }
    });
  
        $("#multiselect_az").click(function() { 
             sort("asc");
        }); 
 
 
  
 
        $("#multiselect_za").click(function() { 
           sort("desc");
        }); 
 
 
 function sort(order)
{ 
             var select = $('#multiselect_to');
             select.html(select.find('option').sort(function(x, y) { 
                if(order=="asc"){ 
                     return ($(x).html()) >  ($(y).html()) ? 1 : -1;
                }else if(order=="desc"){ 
                     return ($(x).html()) <  ($(y).html()) ? 1 : -1;
                }  
            }));  
 }
 
 
 
 
 
 $("[name='checkbox3']").bootstrapSwitch({
	on: 'Enabled',
	off: 'Disabled',
	onClass: 'success',
	offClass: 'warning'
});
 
 
    
       
        $('#spinner1').spinner({value:1, min: 1, max: 6000});
     
 
         $(".form_datetime").datetimepicker({
            autoclose: true,
            isRTL: App.isRTL(),
            format: "dd-mm-yyyy hh:ii",
            pickerPosition: (App.isRTL() ? "bottom-right" : "bottom-left")
        });
 
 
 
  

  
}

 
  handleTable = function()
{
var id,user,pass="";
 

    function pagination_(_totalPages,filter) { 
      window.pagObj = $('#pagination').twbsPagination({
            totalPages: _totalPages,
            visiblePages: 10,
            onPageClick: function (event, page) {
                  tabel('',page,filter)
            }
        }).on('page', function (event, page) {
            
        });
   }


    function tabel(_type,paginate=1,filter="") {  
           $.ajax({ 
            url:  'controllers/users.php',
            data: 'action=get_tabel&_type='+_type+'&paginate='+paginate+'&filter='+filter+'&token='+ $('meta[name="users_token"]').attr('content') ,  
            success: function(data) {  
                    
                    
                     $('#tbl > tbody').html(data.toString());  
                     if($('#tbl .first_tr').length) {  
                       if(_type=="new"){    
                        if($('#pagination').html()!=""){
                            $('#pagination').twbsPagination('destroy'); $('#pagination').html("");
                        } 
                        pagination_($('#tbl .first_tr').attr('lastp'),filter)
                       }
                     }else{
                         if($('#pagination').html()!=""){
                            $('#pagination').twbsPagination('destroy'); $('#pagination').html("");
                        }
                     }  
                 } 
              });  
          }
          
          
          
        function streamrun(_type,_id) { 
             
             $('#str_'+_id+' #vcode').html('<img src="assets/img/loading-gif.gif" width="24" height="24" />'); 
             $('#str_'+_id+' #acode').html('<img src="assets/img/loading-gif.gif" width="24" height="24" />'); 
             
           $.ajax({ 
            url:  'controllers/streams.php',
            data: 'action=streamrun&_type='+_type +'&_id='+_id,  
            success: function(data) { 
                  var json  = $.parseJSON(data.toString()); 
                   if(_type=="start"){
                    
                                       $('#str_'+_id+' #btn_start').addClass( "hiddentag" );
                                       $('#str_'+_id+' #btn_stop').removeClass("hiddentag"); 
                                       $('#str_'+_id+' #vcode').addClass("onlinestr");
                                       $('#str_'+_id+' #acode').addClass("onlinestr"); 
                     if(json.status=="oki"){
                        
                                      $('#str_'+_id+'   #uptime').html(json.uptime); 
                                      $('#str_'+_id+'   #vcode').html(json.vcode); 
                                      $('#str_'+_id+'   #acode').html(json.acode); 
                                      $('#str_'+_id+' #status').html('<img src="assets/img/online.png" width="24" height="24" />');
                     }else{
                                        $('#str_'+_id+' #status').html('<img src="assets/img/offline.png" width="24" height="24" />'); 
                                        $('#str_'+_id+' #vcode').html('<img src="assets/img/nok.png" width="24" height="24" />'); 
                                        $('#str_'+_id+' #acode').html('<img src="assets/img/nok.png" width="24" height="24" />')
                                        $('#str_'+_id+'   #uptime').html('-'); 
                     } 
                    }else if(_type=="stop"){
                                      $('#str_'+_id+'   #uptime').html('-'); 
                                      $('#str_'+_id+'   #vcode').html('-'); 
                                      $('#str_'+_id+'   #acode').html('-'); 
                                       $('#str_'+_id+' #vcode').removeClass("onlinestr");
                                       $('#str_'+_id+' #acode').removeClass("onlinestr"); 
                                       $('#str_'+_id+'   #btn_start').removeClass("hiddentag");
                                       $('#str_'+_id+'   #btn_stop').addClass( "hiddentag" );
                                       $('#str_'+_id+' #status').html('<img src="assets/img/stopped.png" width="24" height="24" />');
                                        
                    }    
                 }
              });  
         }
             
    $('ul.dropdown-menu li').click(function(e) {  
         var sel = $(this).text().trim(); 
         $('ul.dropdown-menu li').removeClass("sel");
         $(this).addClass( "sel" ); 
         $('.dropdown-toggle').html("Filter : "+sel).attr('sel',sel)  
     });
    
    
       $("#filter_btn").click(function() {
        
        
        
        
           var filter_arry = []; 
        
           if (jQuery('.dropdown-toggle').attr("sel")!="None"){
                      filter_arry.push("filter|"+jQuery('.dropdown-toggle').attr("sel").replace(/\s+/g, ''));  
           }  
            if( $("#username").val().length != 0 ) {
                   filter_arry.push("username|"+$('#username').val().trim());  
            }  
              if(filter_arry.toString().trim().length != 0 ) {
                    tabel("new",1,filter_arry.toString().trim())  
              }else{
                           tabel("new")           
              }  
              
              
              
              
      }); 
    
    
    
    
         $('#del').live('click', function() { 
              var ids=$(this).attr('idstr');
              $("#dialog_name").html($('#str_'+ids+' #userstr').html()) 
              $("#delstr").attr('idstr',ids);
              $("#tit").html('Warning!!!');
              $("#don_div").hide();
              $("#deldiv").show()
              $(".modal-footer").show()
              $("#showdialogdel").click()
         });
         
         
         
         $('.getstatus').live('click', function() {  
            var ids=$(this).attr('ids');
            set_sssion(ids); 
            window.location.href="users_status"
          //  location.replace("users_status")  
           // window.location("users_status");
           // location.reload();  
         });
         
         
          
          $('#btn_dis').live('click', function() {
              var ids=$(this).attr('idstr'); 
              var val=$(this).attr('val');
              if(val==1){
                 $(this).attr('val',0) 
                 $(this).css('color', '#ff0000');
              }else{
                $(this).attr('val',1) 
                $(this).css('color', '#33cc33');
              }
              
           $.ajax({ 
            url:  'controllers/users.php',
            data: 'action=set_status&id='+ids+'&token='+ $('meta[name="users_token"]').attr('content') , 
            success: function(data) {   
                } 
           });
             
         });
          
          
          
          
         $('#delstr').click(function() {  
            modalLoading.init(true); 
            var ids=$(this).attr('idstr');
            $.ajax({ 
            url:  'controllers/users.php',
            data: 'action=del&_id='+ids,  
            success: function(data) { 
                  location.reload();
                } 
           });  
         });
    
    
        $('#btn_don').live('click', function() {
              var ids=$(this).attr('idstr');
                user=$('#str_'+ids+' #userstr').html();
                pass=$('#str_'+ids+' #passstr').html();
                $("#urltxt").val(""); 
              $('#listdon option:first').prop('selected',true);
              $("#tit").html('Download Scripts');
              $("#don_div").show();
              $("#deldiv").hide();
              $(".modal-footer").hide();
              $("#showdialogdel").click() ;
         });
          
     $('#listdon').on('change', function () { 
       if(this.value!=""){ 
         var url=this.value;
         url = url.replace("$domain", domain);
         url = url.replace("$user", user);
         url = url.replace("$pass", pass); 
         $("#urltxt").val(url) 
       }else{
        $("#urltxt").val('')
       }  
     });
    
    
    
    
         $('#btn_start').live('click', function() {
            streamrun("start",$(this).attr('idstr'))  
         });
          
          
          
         $('#btn_stop').live('click', function() {
            streamrun("stop",$(this).attr('idstr'))  
         });
          
          
      $('#btn_kill').live('click', function() { 
            var ids=$(this).attr('idstr'); 
            $('#str_'+ids+' .on_of').html('<img src="assets/img/stopped.png" width="20" height="20" />');
            $('#str_'+ids+' .conns').html("0 / "+$('#str_'+ids+' .conns').attr('maxconns'));
            $('#str_'+ids+' .lconn').html("");
            $('#str_'+ids+' .lcha').html("");            
         
            $.ajax({ 
            url:  'controllers/users.php',
            data: 'action=kill_user&_id='+ids+'&token='+ $('meta[name="users_token"]').attr('content') , 
            success: function(data) {   
                } 
           }); 

      });
          
          
          
          
  
   tabel("new")  
 

   
}
 

})(jQuery);