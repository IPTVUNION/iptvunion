
(function ($) {
  add = function()
{
 
 
  var ajaxQueue = $({}); 
  $.ajaxQueue = function(ajaxOpts) { 
    var oldComplete = ajaxOpts.complete; 
    ajaxQueue.queue(function(next) {     
      ajaxOpts.complete = function() { 
        if (oldComplete) oldComplete.apply(this, arguments);   
      }; 
      $.ajax(ajaxOpts);
    });
  };
    
 
  
      $("#can").click(function() {
        window.location.href = "streams"; 
      }); 
 
 
 
 
 
 
$('#type_im').on('change', function () {
      if( this.selectedOptions[0].value==1){
        $('.div_one').show();
        $('.div_multi').hide();
      }else  if( this.selectedOptions[0].value==2){ 
        $('.div_one').hide();
        $('.div_multi').show();
      } 
});
      
 
  
 $('#ffcus').on('change', function () {
      if( this.selectedOptions[0].value==1){ 
         $('#div_ffcus').hide();
         $('#ffcustxt').val('');
      }else  if( this.selectedOptions[0].value==2){  
         $('#div_ffcus').show();
         $('#ffcustxt').val("/home/iptvunion/bin/ffmpeg -probesize 15000000 -analyzeduration 9000000 -user-agent 'iptvunion beta' -i '{input}' -vcodec copy -scodec copy -acodec copy -individual_header_trailer 0  -segment_format mpegts -hls_time 10 -hls_list_size 5   -sc_threshold 0 -hls_flags delete_segments  /home/iptvunion/hls/{id}_.m3u8")
      } 
});                                            
   
            $("#add_url").click(function(e){  
                e.preventDefault();
                $("#listurl").append('<div class="grouptop"> <div class="input-group"><input type="text" class="form-control" name="stream_source[]" id="stream_source[]" placeholder="Enter URL"/> <div class="input-group-btn " id="remove_url"> <button class="btn btn-danger" type="button"  ><i class="fa fa-times"></i></button></div></div></div>');  
            });
            
            $("#listurl").on('click', '#remove_url', function(){  
                 var wrapper = $(this).parent('div')  
                 $(wrapper).parent('div').remove(); 
            });
  
        $('#div_multi').hide();
  
}

 
  handleTable = function()
{

 
 
  var dget=false; 
 
 
setInterval(function() {
   if(dget==false){
     dget=true;
    
        var ids_arr = []; 
    
 $(".list_stream.online").each(function (index, value) {
   if($(this).html().match('loading-gif.gif')){
       ids_arr.push($(this).attr('id').replace(/str_/g, ''));  
   }
 });
    
   if(ids_arr.length !== 0) { 
        $.ajax({ 
            url:  'controllers/streams.php',
            data: 'action=get_stream_info&list='+ids_arr.toString().trim()+'&token='+ $('meta[name="streams_token"]').attr('content') ,   
            success: function(data) {   
                       var json  = $.parseJSON(data.toString());  
                       if(json.length !== 0) {  
                           jQuery.each(ids_arr, function(i, index) {
                                 if(json[index].status=="oki"){
                                    $('#str_'+index+'   #vcode').html(json[index].vcode); 
                                   $('#str_'+index+'   #acode').html(json[index].acode);  
                                 }else if(json[index].status=="err"){
                                        $('#str_'+index+'').removeClass( "online" ); 
                                        $('#str_'+index+' #status').html('<img src="assets/img/offline.png" width="24" height="24" />'); 
                                        $('#str_'+index+' #vcode').html('<img src="assets/img/nok.png" width="24" height="24" />'); 
                                        $('#str_'+index+' #acode').html('<img src="assets/img/nok.png" width="24" height="24" />')
                                        $('#str_'+index+'   #uptime').html('-'); 
                                }
                          }); 
                        

                     } 
                 } 
              }); 
   }
    
     dget=false; 
    }
}, 9000);
 
 
 
 
 
 
 
 
 
 
    function pagination_(_totalPages,filter) { 
      window.pagObj = $('#pagination').twbsPagination({
            totalPages: _totalPages,
            visiblePages: 10,
            onPageClick: function (event, page) {
                  tabel('',page,filter)
            }
        }).on('page', function (event, page) {
            
        });
   }


    function tabel(_type,paginate=1,filter="") {  
           $.ajax({ 
            url:  'controllers/streams.php',
            data: 'action=get_tabel&_type='+_type+'&paginate='+paginate+'&filter='+filter+'&token='+ $('meta[name="streams_token"]').attr('content') ,  
            success: function(data) {  
                     $('#tbl > tbody').html(data.toString());  
                     if($('#tbl .first_tr').length) {  
                       if(_type=="new"){    
                        if($('#pagination').html()!=""){
                            $('#pagination').twbsPagination('destroy'); $('#pagination').html("");
                        } 
                        pagination_($('#tbl .first_tr').attr('lastp'),filter)
                       }
                     }else{
                         if($('#pagination').html()!=""){
                            $('#pagination').twbsPagination('destroy'); $('#pagination').html("");
                        }
                     }  
                 } 
              });  
          }
          
          
          
        function streamrun(_type,_id) { 
             
             $('#str_'+_id+' #vcode').html('<img src="assets/img/loading-gif.gif" width="24" height="24" />'); 
             $('#str_'+_id+' #acode').html('<img src="assets/img/loading-gif.gif" width="24" height="24" />'); 
             
           $.ajax({ 
            url:  'controllers/streams.php',
            data: 'action=streamrun&_type='+_type +'&_id='+_id,  
            success: function(data) { 
                  var json  = $.parseJSON(data.toString()); 
                   if(_type=="start"){
                    
                                       $('#str_'+_id+' #btn_start').addClass( "hiddentag" );
                                       $('#str_'+_id+' #btn_stop').removeClass("hiddentag"); 
                                       $('#str_'+_id+' #vcode').addClass("onlinestr");
                                       $('#str_'+_id+' #acode').addClass("onlinestr"); 
                     if(json.status=="oki"){
                      
                                      $('#str_'+_id+'').addClass( "online" );
                                      $('#str_'+_id+'   #uptime').html(json.uptime); 
                                  // $('#str_'+_id+'   #vcode').html(json.vcode); 
                                 //     $('#str_'+_id+'   #acode').html(json.acode); 
                                      $('#str_'+_id+' #status').html('<img src="assets/img/online.png" width="24" height="24" />');
                     }else{
                                        $('#str_'+_id+'').removeClass( "online" ); 
                                        $('#str_'+_id+' #status').html('<img src="assets/img/offline.png" width="24" height="24" />'); 
                                        $('#str_'+_id+' #vcode').html('<img src="assets/img/nok.png" width="24" height="24" />'); 
                                        $('#str_'+_id+' #acode').html('<img src="assets/img/nok.png" width="24" height="24" />')
                                        $('#str_'+_id+'   #uptime').html('-'); 
                     } 
                    }else if(_type=="stop"){
                                      $('#str_'+_id+'').removeClass( "online" ); 
                                      $('#str_'+_id+'   #uptime').html('-'); 
                                      $('#str_'+_id+'   #vcode').html('-'); 
                                      $('#str_'+_id+'   #acode').html('-'); 
                                       $('#str_'+_id+' #vcode').removeClass("onlinestr");
                                       $('#str_'+_id+' #acode').removeClass("onlinestr"); 
                                       $('#str_'+_id+'   #btn_start').removeClass("hiddentag");
                                       $('#str_'+_id+'   #btn_stop').addClass( "hiddentag" );
                                       $('#str_'+_id+' #status').html('<img src="assets/img/stopped.png" width="24" height="24" />');
                                        
                    }    
                 }
              });  
         }
                
             
    $('ul.dropdown_fil li').click(function(e) {  
         var sel = $(this).text().trim(); 
         $('ul.dropdown_fil li').removeClass("sel");
         $(this).addClass( "sel" ); 
         
         $('.dropdownfil-toggle').html('Filter : '+sel+' <i class="fa fa-angle-down"></i>').attr('sel',sel) 
         
         
         
         
         
         
         $("#name").prop('disabled', false);
          $('.dropdownact-toggle').html('Action : None <i class="fa fa-angle-down"></i>').attr('sel',"None") 
         $('.dropdown_act li').not('li:first').remove(); 
         
            if(sel!=="None"){  
            if(sel==="Stopped"){
               $('.dropdown_act').append('<li class=""><a href="javascript:;">Start</a></li>');
            }
            
             if(sel==="Online"|sel==="Offline"){
               $('.dropdown_act').append('<li><a href="javascript:;">Stop</a></li>');
            }
            
            if(sel==="Offline"){
               $('.dropdown_act').append('<li><a href="javascript:;">Restart</a></li>');
            }
            
         }else{ 
         }
         
     });
       $('ul.dropdown_act li').live('click', function(){
         var sel = $(this).text().trim(); 
         $('ul.dropdown_act li').removeClass("sel");
         $(this).addClass( "sel" ); 
         $('.dropdownact-toggle').html('Action : '+sel+' <i class="fa fa-angle-down"></i>').attr('sel',sel)  
          
         if(sel==="None"){
             $("#name").prop('disabled', false);
         }else{
            $("#name").prop('disabled', true);
         } 
     }); 
    
       $("#filter_btn").click(function() {
         
               
        if(jQuery('.dropdownfil-toggle').attr("sel")!=="None"){
              var filter_arry = []; 
        
           if (jQuery('.dropdownact-toggle').attr("sel")==="None"){
                      filter_arry.push("filter|"+jQuery('.dropdownfil-toggle').attr("sel"));   
            if( $("#name").val().length != 0 ) {
                   filter_arry.push("name|"+$('#name').val().trim());  
            }  
              if(filter_arry.toString().trim().length != 0 ) {
                    tabel("new",1,filter_arry.toString().trim())  
              }else{
                           tabel("new")           
              } 
      
      }else{  
               $('body').addClass("disabledall");
               $('#wait_div').addClass("active"); 
  
         $.ajax({ 
         url:  'controllers/streams.php',
         data: 'action=set_streams&_type='+jQuery('.dropdownfil-toggle').attr("sel")+'&filter='+jQuery('.dropdownact-toggle').attr("sel")+'&token='+ $('meta[name="streams_token"]').attr('content') ,    
         success: function(data) {
           
            window.location.href = "streams"; 
             
             
             
             
              // $('body').removeClass("disabledall");
            //   $('#wait_div').removeClass("active");  
              
             
          }
        });

       
      
        } 
         
          
        } 
              
              
              
              
              
              
              
              
              
               
      }); 

    
    
    
    
    

    
 

    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
         $('#del').live('click', function() { 
              var ids=$(this).attr('idstr');
              $("#dialog_name").html($('#str_'+ids+' #namestr').html()) 
              $("#delstr").attr('idstr',ids)
              $("#showdialogdel").click()
         });
          
         $('#delstr').click(function() {  
             modalLoading.init(true); 
            var ids=$(this).attr('idstr');
            $.ajax({ 
            url:  'controllers/streams.php',
            data: 'action=del&_id='+ids,  
            success: function(data) { 
                  location.reload();
                } 
           });  
         });
    
    
    
    
    
    
    
         $('#btn_start').live('click', function() {
            streamrun("start",$(this).attr('idstr'))  
         });
          
          
          
         $('#btn_stop').live('click', function() {
            streamrun("stop",$(this).attr('idstr'))  
         });
          
          
          
          
          
          
  
   tabel("new")  
 
 
 
 
 
 
 
 
 function screenClass() { 
    if($(window).innerWidth() < 500) {
    
    }if($(window).innerWidth() < 960) {
        
     }else {
           
    }
} 
screenClass(); 
$(window).bind('resize',function(){
    screenClass();
});
 
 
 
 
 
 
 

   
}
 

})(jQuery);