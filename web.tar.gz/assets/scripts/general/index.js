(function ($) { 
jQuery(document).ready(function() {    
 
 var dget=false; 
 
 
 var useram=$('#useram').attr('data-percent'); 
 var usehdd=$('#usehdd').attr('data-percent');
 var usecpu=$('#usecpu').attr('data-percent');
 
 
setInterval(function() {
   if(dget==false){
   dget=true;
   
   
   
    $.ajax({ 
            url:  'controllers/index.php',
            data: 'action=get_data&token='+ $('meta[name="index_token"]').attr('content') ,  
            success: function(data) {  
                     var json  = $.parseJSON(data.toString()); 
                     $("#total_bo").html(json.bandwidth.out)
                     $("#total_bi").html(json.bandwidth.in)
                     $("#total_u").html(json.user_info.total)
                     $("#uon").html(json.user_info.online)
                     $("#uof").html(json.user_info.offline)
                     $("#total_c").html(json.user_info.oconn)
                     $("#total_s").html(json.streams_info.total)
                     $("#son").html(json.streams_info.online)
                     $("#sof").html(json.streams_info.offline+" | "+json.streams_info.error);
                      
                     if(useram!=json.useram){ 
                     useram=json.useram; 
                     $('#useram').empty().removeData().attr('data-percent', json.useram).circliful();
                     $("#useram .circle-text-half").html(json.useram+"%");  
                     }
                     
                     if(usehdd!=json.usehdd){
                     usehdd=json.usehdd; 
                     $('#usehdd').empty().removeData().attr('data-percent', json.usehdd).circliful();
                     $("#usehdd .circle-text-half").html(json.usehdd+"%");  
                     }
                    
                     if(usecpu!=json.usecpu){
                     usecpu=json.usecpu; 
                     $('#usecpu').empty().removeData().attr('data-percent', json.usecpu).circliful();
                     $("#usecpu .circle-text-half").html(json.usecpu+"%");  
                     }
                     
                     dget=false;  
                 } 
              });
            }
}, 30000);
  
  
   $('#useram').circliful();
   $('#usehdd').circliful();
   $('#usecpu').circliful();
   
   
   
   
   
    
    
 
 function screenClass() { 
     if($(window).innerWidth() > 500) { 
       $('.other_info').show() 
       $('.mobile_info').hide()
           
    }else{
        
          $('.other_info').hide() 
       $('.mobile_info').show()
        
        
    }
} 
screenClass(); 
$(window).bind('resize',function(){
   // screenClass();
});
 
 
 
 
   
   
   
   
   
   
   
   
 })
})(jQuery);