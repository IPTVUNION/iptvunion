
(function ($) {
 
 
  handleTable = function()
{
 var ids=0;
 
 
 
 
 
 
 $('.editbtn').live('click', function() {    
   $('#aded').html("Edit") 
   $('#username').val($(this).attr('user')) 
   $('#password').val($(this).attr('pass'))
   $('#sav').html("Save")
   $('#can').show() 
   ids=$(this).attr('ids'); 
 })
 
 
 
  $('#can').live('click', function() {   
   $('#username_div').removeClass("has-error");
   $('#username_div .help-block').html("") 
   $('#username').val("") 
   $('#password_div').removeClass("has-error");
   $('#password_div .help-block').html("") 
   $('#password').val("") 
   $('#aded').html("ADD") 
   $('#sav').html("insert")
   $('#can').hide() 
   ids=0; 
  })
  
 
 
 
 
         $('.delbtn').live('click', function() {  
              $("#dialog_name").html($(this).attr('val')) 
              $("#delstr").attr('idstr',$(this).attr('ids')); 
              $("#showdialogdel").click()
         });
           
         $('#delstr').click(function() { 
           // $('#openModalLoading').show()
          // modalLoading.init(true);  
            var ids=$(this).attr('idstr'); 
            $.ajax({
            url: 'controllers/admin-users.php',
            data: 'action=del&id=' + $(this).attr('idstr') + '&token=' + $('meta[name="adminusers_token"]').attr('content'),
            success: function(data) {   
                   var json = $.parseJSON(data.toString()); 
                   if(json.hasOwnProperty('error')){  
                  }else{ 
                    $('[data-id="'+ids+'"]').remove();
                   //    $('#openModalLoading').hide(); 
                  } 
                } 
           }); 
         }); 
 
 
 
  
 
 
 
           $('#btn_dis').live('click', function() {
              var ids=$(this).attr('idstr'); 
              var val=$(this).attr('val');
              
              if(val==1){
                 $(this).attr('val',0) 
                 $(this).css('color', '#ff0000');
              }else{
                $(this).attr('val',1) 
                $(this).css('color', '#33cc33');
              }
               
           $.ajax({ 
            url:  'controllers/admin-users.php',
            data: 'action=set_status&id='+ids+'&token='+ $('meta[name="adminusers_token"]').attr('content') , 
            success: function(data) {    
                } 
           });
             
         });
 
 
 
 
 
 
 
  $('#sav').live('click', function() {   
            $.ajax({
            url: 'controllers/admin-users.php',
            data: 'action=sav_add&id=' + ids + '&username=' + $('#username').val() + '&password=' + $('#password').val() + '&token=' + $('meta[name="adminusers_token"]').attr('content'), 
            success: function(data) {  
                    var json = $.parseJSON(data.toString()); 
                    if(json.hasOwnProperty('error')){  
                         
                         if(json.error.hasOwnProperty('username')){ 
                             $('#username_div').addClass("has-error");
                             $('#username_div .help-block').html(json.error.username)   
                          }
                         
                            if(json.error.hasOwnProperty('password')){ 
                             $('#password_div').addClass("has-error");
                             $('#password_div .help-block').html(json.error.password)   
                          }
                         
                         
                          if(json.error.hasOwnProperty('permission')){ 
                              alert(json.error.permission)  
                          }
                          

                    }else{  
                         if(json.hasOwnProperty('lid')){  
                                   var addata='<li class="dd-item" data-id="'+json.lid+'">' +
									          '<div class="dd-handle-nodrag"><span>username : </span><span id="user">'+$('#username').val()+'</span> |   <span>password : </span><span id="pass">'+$('#password').val()+'</span></div>'+ 
                                              '<div  style="margin-top: -27px; margin-right:10px; float: right;">'+
                                              '<i class="btndel fa fa-power-off fbtn" style="margin-top: -5px;cursor: pointer;color: #33cc33;"  id="btn_dis" val="1" idstr="'+json.lid+'" title="Enable/Disable"></i>'+ 
                                              ' <i class="fa fa-pencil btn_cate editbtn" ids="'+json.lid+'" user="'+$('#username').val()+'" pass="'+$('#password').val()+'"></i>'+
                                              ' <i class="fa fa-trash-o btn_cate delbtn" ids="'+json.lid+'" user="'+$('#username').val()+'" pass="'+$('#password').val()+'"></i> '+
                                              '</div>'+ 
									          '</li>';  
                            $('.dd-list').append(addata) 
                         }else{
                             $('[data-id="'+ids+'"]  .userval').html($('#username').val());  
                             $('[data-id="'+ids+'"]  .passval').html($('#password').val());
                         } 
                         
                         
                       $('#can').click() 
                    }    
            } 
            }); 
 })
 
 
    
 
 
 




}
 

})(jQuery);