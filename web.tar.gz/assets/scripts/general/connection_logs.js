
(function ($) {
  add = function()
{ 
jQuery(document).ready(function() {    
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 function getconnlog() {   
            $.ajax({ 
            url:  'controllers/connection_logs.php',
            data: 'action=getconnlog&token='+ $('meta[name="connection_logs_token"]').attr('content') ,  
            success: function(data) {  
   var data_list = $.parseJSON(data.toString());  
   var tbl_list = [];
   $('#tbl > tbody  > tr').each(function() {  
         tbl_list.push($(this).attr('iduser')); 
   }); 
   if (tbl_list.length != 0) {
   tbl_list = tbl_list.sort((a, b) => a - b);
   var list_ofline = tbl_list.filter(function(obj) { return data_list.ids.indexOf(obj) === -1; });  
   var list_online = tbl_list.filter(function(obj) { return data_list.ids.indexOf(obj) !== -1; }); 
    $.each(list_ofline, function (index, txt) {  
     $('#tbl > tbody  > tr[iduser="'+txt+'"]').remove();
    });   
   }
    var txtlist="";
    $.each(data_list.list, function (index, txt) { 
      if(jQuery.inArray(txt.key, list_online) === -1){
          
         var totaltime=get_time(txt.time_total);
          
      txtlist+="<tr iduser='"+txt.key+"'>"+
          // "<td>"+txt.id+"</td>"+
           "<td  >"+txt.username+"</td>"+
           "<td class='tbltdcenter' >"+txt.channel+"</td>"+
           "<td  >"+txt.ip+"</td>"+
           "<td  >"+txt.flag+"</td>"+
           "<td  title='"+txt.player+"'>"+txt.player.substr(0, 30)+"...</td>"+
           "<td  id='time_start'>"+txt.date_start+"</td>"+
           "<td  id='total_time_online' val_sec='"+txt.time_total+"'>"+totaltime+"</td> "+ 
           "</tr>"; 
         }
    });
     
      if($('#tbl > tbody').is(":empty")){
              $('#tbl > tbody').html(txtlist);   
      }else{ 
              $('#tbl > tbody > tr:first').before(txtlist);   
      }               
       
     
  setTimeout(function(){getconnlog();}, 20000); 
  
                 }
              });   
 } 

 getconnlog();
 
 
 
 
 
  
 function get_time(time_total) {  
 var retval; 
  retval=time_total; 
 var seconds = parseInt(retval, 10); 
var days = Math.floor(seconds / (3600*24));
seconds  -= days*3600*24;
var hrs   = Math.floor(seconds / 3600);
seconds  -= hrs*3600;
var mnts = Math.floor(seconds / 60);
seconds  -= mnts*60; 
 time_total="";
 if(days!=0){
    time_total=days+"d ";
 }
 if(hrs!=0){
    time_total+=hrs+"h ";
 } 
 if(mnts!=0){
    time_total+=mnts+"m ";
 } 
 if(seconds!=0){
    time_total+=seconds+"s ";
 }
  
     return time_total;
 }
 
 
  
 
 function chk_times() {    
  $('#tbl > tbody  > tr').each(function() {    
     var times=parseInt($(this).find('#total_time_online').attr('val_sec'))+1;  
     $(this).find('#total_time_online').attr('val_sec',times); 
     $(this).find('#total_time_online').html(get_time(times)); 
  });         
   setTimeout(function(){chk_times();}, 1000);          
 } 
 chk_times();
 
 
 
 
 
 
 
 
  
}); 
} 
})(jQuery);