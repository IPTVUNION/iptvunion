(function ($) { 
jQuery(document).ready(function() {    
 
 

2
3
4
5
6
7 
	jQuery('.skillbar-info').each(function(){
		jQuery(this).find('.skillbar-info-bar').animate({
			width:jQuery(this).attr('data-percent')
		},6000);
	});
 


 
 })
})(jQuery);