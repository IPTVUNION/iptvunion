
(function ($) {
  add = function()
{
 
 var type_run="pc";

 
 if ($(window).width() < 700){ 
    $('#multiselect_mobile_div').show()
    $('#multiselect_pc_div').hide() 
    $('#from_mobile_div').show()
  // $('#multiselect_to_div').hide();
    
     
        $("#multiselect_rightAll").click(function() {  
           $("#from_mobile").append($("#multiselect_mobile").html().toString())
           $("#multiselect_mobile").html("");  
           $("#from_mobile > li").each(function () { $(this).removeClass("list-group-sel"); }); 
        }); 
     
         
         $("#multiselect_rightSelected").click(function() {  
         $("#multiselect_mobile > li").each(function () {
           if ($(this).hasClass("list-group-sel")) { 
                 $("#from_mobile").append($(this).removeClass("list-group-sel").clone())
                 $(this).remove();
           }
          });  
         }); 
          
          
         
         $("#multiselect_leftSelected").click(function() {  
         $("#from_mobile > li").each(function () {
           if ($(this).hasClass("list-group-sel")) { 
                 $("#multiselect_mobile").append($(this).removeClass("list-group-sel").clone())
                 $(this).remove();
           }
          });  
         });     
         
          
         $("#multiselect_leftAll").click(function() {  
           $("#multiselect_mobile").append($("#from_mobile").html().toString())
           $("#from_mobile").html(""); 
           $("#multiselect_mobile > li").each(function () { $(this).removeClass("list-group-sel"); });
         });  
    
    
 $("#multiselect_move_up").click(function() {     
 if($('#from_mobile li').length > $('#from_mobile li.list-group-sel').length & $('#from_mobile li.list-group-sel').length !=0) 
        var li_back =   $('#from_mobile li.list-group-sel').first().prev();    
          var  sel_li_list="";
         $("#from_mobile > li").each(function () { 
               if ($(this).hasClass("list-group-sel")) {
                  sel_li_list+=$(this)[0].outerHTML;
                  $(this).remove();
                }
          });    
        if (li_back.length){
             $(sel_li_list).insertBefore(li_back);
        }else{
           $('#from_mobile').html(sel_li_list + $('#from_mobile').html()); 
        }   
 });

 $("#multiselect_move_down").click(function() {    
     if($('#from_mobile li').length > $('#from_mobile li.list-group-sel').length & $('#from_mobile li.list-group-sel').length !=0) 
        var li_after =   $('#from_mobile li.list-group-sel').last().next().after();   
          var  sel_li_list="";
         $("#from_mobile > li").each(function () { 
               if ($(this).hasClass("list-group-sel")) {
                  sel_li_list+=$(this)[0].outerHTML;
                  $(this).remove();
                }
          });   
           
        if (li_after.length){
             $(sel_li_list).insertAfter(li_after);
        }else{
            $('#from_mobile').append(sel_li_list);
        } 
           
 });


 $("#multiselect_az").click(function() {    
          $("#from_mobile li").sort(asc_sort).appendTo('#from_mobile'); 
 });


 $("#multiselect_za").click(function() {     
        $("#from_mobile li").sort(dec_sort).appendTo('#from_mobile'); 
 });


 function asc_sort(a, b){
    return ($(b).text()) < ($(a).text()) ? 1 : -1;    
}

 
function dec_sort(a, b){
    return ($(b).text()) > ($(a).text()) ? 1 : -1;    

}
 
 
        
 $('#multiselect_mobile li').live('click', function() {
    if($(this).hasClass('list-group-sel')){
           $(this).removeClass('list-group-sel');
     }else{ 
            $(this).addClass('list-group-sel');
     }
 }); 
    
    
    
 $('#from_mobile li').live('click', function() {
    if($(this).hasClass('list-group-sel')){
           $(this).removeClass('list-group-sel');
     }else{ 
            $(this).addClass('list-group-sel');
     }
 }); 
    
    
     
     
     
     
     
     
  
 $('#submit1').click(function(e) {   
    var all_list="";
   $('#from_mobile li').each(function () {
   var list = $(this)[0].outerHTML 
   all_list+=list; 
   }); 
   all_list=all_list.replace(/<li/gi,"<option")
   all_list=all_list.replace(/<\/li/gi,"</option");    
   $('#multiselect_to').html(all_list);   
   $('#multiselect_to option').attr('selected', true); 
  });
    
  
     
     
     
     
     
     
 $('#from_ser').keyup(function(){ 
    var that = this, $allListElements = $('#multiselect_mobile > li');

    var $matchingListElements = $allListElements.filter(function(i, li){
        var listItemText = $(li).text().toUpperCase(), searchText = that.value.toUpperCase();
        return ~listItemText.indexOf(searchText);
    });
    
    $allListElements.hide();
    $matchingListElements.show(); 
 });

     
     
 $('#in_ser').keyup(function(){ 
    var that = this, $allListElements = $('#from_mobile > li');

    var $matchingListElements = $allListElements.filter(function(i, li){
        var listItemText = $(li).text().toUpperCase(), searchText = that.value.toUpperCase();
        return ~listItemText.indexOf(searchText);
    });
    
    $allListElements.hide();
    $matchingListElements.show(); 
 }); 
     
     
     
     
     
     
     
     
     
         
 }else{ 
    $('#multiselect_mobile_div').hide()
    $('#multiselect_pc_div').show()  
    $('#from_mobile_div').hide()
    $('#multiselect_to_div').show();  
    
    
   
    
    
    
    
    
 }
 
 
                     
             
    //$("#from_mobile").html();
    
    
    
 
     $('#multiselect').multiselect({
        search: {
            left: '<input type="text" name="q" class="form-control" placeholder="Search..." />',
            right: '<input type="text" name="q" class="form-control" placeholder="Search..." />',
        },
        fireSearch: function(value) {
            return value.length > 3;
        }
    });
  
        $("#multiselect_az").click(function() { 
             sort("asc");
        }); 
 
 
  
 
        $("#multiselect_za").click(function() { 
           sort("desc");
        }); 
 
 
 function sort(order)
{ 
             var select = $('#multiselect_to');
             select.html(select.find('option').sort(function(x, y) { 
                if(order=="asc"){ 
                     return ($(x).html()) >  ($(y).html()) ? 1 : -1;
                }else if(order=="desc"){ 
                     return ($(x).html()) <  ($(y).html()) ? 1 : -1;
                }  
            }));  
 }
 
 
                             
  
 
     
       $("#can").click(function() {
        window.location.href = "bouquets"; 
      }); 
 
 
  
 


 
 
 
  
  
}

 
  handleTable = function()
{ 
var id,user,pass="";
var domain="195.201.172.39:8000";

    function pagination_(_totalPages,filter) { 
      window.pagObj = $('#pagination').twbsPagination({
            totalPages: _totalPages,
            visiblePages: 10,
            onPageClick: function (event, page) {
                  tabel('',page,filter)
            }
        }).on('page', function (event, page) {
            
        });
   }


    function tabel(_type,paginate=1,filter="") {  
           $.ajax({ 
            url:  'controllers/bouquets.php',
            data: 'action=get_tabel&_type='+_type+'&paginate='+paginate+'&filter='+filter+'&token='+ $('meta[name="bouquets_token"]').attr('content') ,  
            success: function(data) {  
                    
                    
                     $('#tbl > tbody').html(data.toString());  
                     if($('#tbl .first_tr').length) {  
                       if(_type=="new"){    
                        if($('#pagination').html()!=""){
                            $('#pagination').twbsPagination('destroy'); $('#pagination').html("");
                        } 
                        pagination_($('#tbl .first_tr').attr('lastp'),filter)
                       }
                     }else{
                         if($('#pagination').html()!=""){
                            $('#pagination').twbsPagination('destroy'); $('#pagination').html("");
                        }
                     }  
                 } 
              });  
          }
          
          
          
        
             
    $('ul.dropdown-menu li').click(function(e) {  
         var sel = $(this).text().trim(); 
         $('ul.dropdown-menu li').removeClass("sel");
         $(this).addClass( "sel" ); 
         $('.dropdown-toggle').html("Filter : "+sel).attr('sel',sel)  
     });
    
    
       $("#filter_btn").click(function() {
        
           var filter_arry = []; 
        
            
            if( $("#bname").val().length != 0 ) {
                   filter_arry.push("bname|"+$('#bname').val().trim());  
            }  
              if(filter_arry.toString().trim().length != 0 ) {
                    tabel("new",1,filter_arry.toString().trim())  
              }else{
                           tabel("new")           
              }  
      }); 
    
    
    
    
         $('#del').live('click', function() { 
              var ids=$(this).attr('idstr');
              $("#dialog_name").html($('#str_'+ids+' #bouquetstr').html()) 
              $("#delstr").attr('idstr',ids);
              $("#tit").html('Warning!!!');
              $("#don_div").hide();
              $("#deldiv").show()
              $(".modal-footer").show()
              $("#showdialogdel").click()
         });
          
         $('#delstr').click(function() {  
            modalLoading.init(true); 
            var ids=$(this).attr('idstr');
            $.ajax({ 
            url:  'controllers/bouquets.php',
            data: 'action=del&_id='+ids,  
            success: function(data) { 
                  location.reload();
                } 
           });  
         });
    
 
       
  
  
   tabel("new")  
  
}
 

})(jQuery);