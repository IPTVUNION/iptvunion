
(function ($) { 
  handleTable = function()
{
 var ids=0;
  
   $('.autos').on('switchChange.bootstrapSwitch', function (event, state) {  
              if (state == true){
                   state=1;
               }else{
                   state=0;
               } 
            $.ajax({ 
            url:  'controllers/setting.php',
            data: 'action='+$(this).attr('name')+'&state='+state+'&token='+ $('meta[name="setting_token"]').attr('content'),  
            success: function(data) {   
            } 
            });       
    });
  
 
 
  $(".help-block").hide();
 
 
   $("form").submit(function(e){
        e.preventDefault();
    });
 
 
   $("#saved").click(function() { 
           $.ajax({ 
            url:  'controllers/setting.php',
            data: 'action=saved&domain='+$('#domain').val()+'&token='+ $('meta[name="setting_token"]').attr('content'), 
            success: function(data) {  
                if(data.toString()!=""){
                         $('#domain_div').addClass("has-error");  
                         $("#domain_div .help-block").html(data.toString());
                         $("#domain_div .help-block").show(); 
                }else{
                         $('#domain_div').removeClass("has-error"); 
                         $("#domain_div .help-block").html("");
                         $("#don_div .help-block").hide();
                }
           }
          }); 
   }); 
 
 
 
 
 
 
} 
})(jQuery);