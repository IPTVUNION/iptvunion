
(function ($) {
 
 
  handleTable = function()
{
 var ids=0;
  function updateOutput(order)
{ 

            var list = order.length ? order : $(order.target),
            output = list.data('output');
 

 

 
        $.ajax({
            url: 'controllers/categories.php',
            data: 'action=sort&sort_list=' + JSON.stringify(list.nestable('serialize')) + '&token=' + $('meta[name="categories_token"]').attr('content'), 
        });

 


}

 $('.editbtn').live('click', function() {  
   $('#aded').html("Edit") 
   $('#cname').val($(this).attr('val'))
   $('#sav').html("Save")
   $('#can').show() 
   ids=$(this).attr('ids'); 
 })
 
 
 
  $('#can').live('click', function() {  
   $('#cname_div').removeClass("has-error");
   $('#cname_div .help-block').html("") 
   $('#aded').html("ADD") 
   $('#cname').val("")
   $('#sav').html("insert")
   $('#can').hide() 
   ids=0; 
  })
 
 
 
 
 
         $('.delbtn').live('click', function() {  
              $("#dialog_name").html($(this).attr('val')) 
              $("#delstr").attr('idstr',$(this).attr('ids')); 
              $("#showdialogdel").click()
         });
          
         $('#delstr').click(function() { 
            $('#openModalLoading').show()
            modalLoading.init(true);  
            var ids=$(this).attr('idstr');
            $.ajax({
            url: 'controllers/categories.php',
            data: 'action=del&id=' + $(this).attr('idstr') + '&token=' + $('meta[name="categories_token"]').attr('content'),
            success: function(data) {   
                   $('[data-id="'+ids+'"]').remove(); 
                   $('#openModalLoading').hide();
                } 
           }); 
         }); 
 
 
 
 
 
 
 
  $('#sav').live('click', function() {   
            $.ajax({
            url: 'controllers/categories.php',
            data: 'action=sav_add&id=' + ids + '&name=' + $('#cname').val() + '&token=' + $('meta[name="categories_token"]').attr('content'), 
            success: function(data) {  
                    var json = $.parseJSON(data.toString()); 
                    if(json.hasOwnProperty('error')){  
                         $('#cname_div').addClass("has-error");
                         $('#cname_div .help-block').html(json.error)  
                    }else{  
                         if(json.hasOwnProperty('lid')){  
                                   var addata='<li class="dd-item" data-id="'+json.lid+'">' +
									          '<div class="dd-handle">'+$('#cname').val()+'</div>'+ 
                                              '<div  style="margin-top: -27px; margin-right:10px; float: right;">'+ 
                                              ' <i class="fa fa-pencil btn_cate editbtn" ids="'+json.lid+'" val="'+$('#cname').val()+'"></i>'+
                                              ' <i class="fa fa-trash-o btn_cate delbtn" ids="'+json.lid+'" val="'+$('#cname').val()+'"></i> '+
                                              '</div>'+ 
									          '</li>';  
                            $('.dd-list').append(addata) 
                         }else{
                             $('[data-id="'+ids+'"] .dd-handle').html($('#cname').val());  
                         } 
                         
                         
                       $('#can').click() 
                    }    
            } 
            }); 
 })
 
 
        $('#nestable_list_1').nestable().on('change', updateOutput);
        
 
 
 




}
 

})(jQuery);