<head>
<meta http-equiv="refresh" content="1;URL=https://onlineaviakassa.com" />
</head>